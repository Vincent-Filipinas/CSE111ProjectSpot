delete from artist;
delete from song;
delete from playlist;
delete from stats;
delete from charts;
